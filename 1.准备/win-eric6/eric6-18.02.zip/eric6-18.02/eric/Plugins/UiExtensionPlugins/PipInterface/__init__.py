# -*- coding: utf-8 -*-

# Copyright (c) 2015 - 2018 Detlev Offenbach <detlev@die-offenbachs.de>
#

"""
Package implementing the various pip dialogs and data.
"""

from __future__ import unicode_literals

DefaultIndexUrl = "https://pypi.python.org/pypi"
